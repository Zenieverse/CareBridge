// swift-tools-version:5.7
import PackageDescription
let package = Package(
    name: "CareBridge",
    platforms: [.iOS(.v16)],
    products: [
        .library(name: "CareBridge", targets: ["CareBridge"]),
    ],
    targets: [
        .target(name: "CareBridge", path: "Sources/CareBridge"),
        .testTarget(name: "CareBridgeTests", dependencies: ["CareBridge"], path: "Tests")
    ]
)