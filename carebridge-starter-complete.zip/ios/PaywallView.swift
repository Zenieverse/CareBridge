import SwiftUI
import RevenueCat

struct PaywallView: View {
    var onPurchase: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text("Support CareBridge")
                .font(.title)
                .bold()
            Text("Become a monthly supporter to remove fees and unlock perks.")
                .multilineTextAlignment(.center)
                .padding()

            Button("Purchase — $3.99/mo") {
                purchaseSupporter()
            }
            .buttonStyle(.borderedProminent)

            Button("Donate via Web Checkout") {
                openWebDonation()
            }
            .buttonStyle(.bordered)

            Button("Close") {
                // close sheet
            }
        }
        .padding()
    }

    func purchaseSupporter() {
        // Example purchase flow (pseudo-code)
        Purchases.shared.getOfferings { offerings, error in
            if let package = offerings?.current?.availablePackages.first {
                Purchases.shared.purchase(package: package) { transaction, customerInfo, error, userCancelled in
                    if customerInfo?.entitlements.all["supporter"]?.isActive == true {
                        onPurchase()
                    }
                }
            }
        }
    }

    func openWebDonation() {
        // Open Stripe Checkout on mobile safari — server creates session
        if let url = URL(string: "https://your-server.example.com/create-checkout-session") {
            UIApplication.shared.open(url)
        }
    }
}
