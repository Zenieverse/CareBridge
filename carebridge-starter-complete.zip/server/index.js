// Simple Express server: creates Stripe Checkout session and listens for RevenueCat webhooks
const express = require('express');
const app = express();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');
app.use(express.json());

app.get('/', (req, res) => res.send('CareBridge stub server'));

app.post('/create-checkout-session', async (req, res) => {
  // In production, get donation amount from body
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'payment',
    line_items: [{
      price_data: {
        currency: 'usd',
        product_data: { name: 'CareBridge Boost Donation' },
        unit_amount: 200
      },
      quantity: 1
    }],
    success_url: 'https://your-app/success',
    cancel_url: 'https://your-app/cancel'
  });
  res.json({ url: session.url });
});

app.post('/webhooks/revenuecat', (req, res) => {
  // Verify signature in production
  console.log('RevenueCat webhook received:', req.body);
  // Update your user entitlements accordingly
  res.sendStatus(200);
});

const port = process.env.PORT || 4242;
app.listen(port, () => console.log('Server running on', port));
