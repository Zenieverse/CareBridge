This folder contains SwiftUI source files to be integrated into an Xcode project.
Create a new SwiftUI App in Xcode and add the following files into the project.
