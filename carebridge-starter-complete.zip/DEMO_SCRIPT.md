
CareBridge Demo Video Script (Target length: 2-3 minutes)

0:00-0:10 — Intro (Title card, app logo)
Voiceover: "CareBridge — connecting neighbors in real need with trusted volunteers."

0:10-0:35 — Onboarding & Profiles
Show: Launch app, Sign in with Apple, choose Resident/Volunteer/Organizer, brief profile.
Voiceover: "Quick onboarding, choose your role and location."

0:35-1:10 — Create a Request
Show: Resident creates a Grocery Pickup request, sets urgency, optional donation.
Voiceover: "Residents create short requests with clear tags and urgency."

1:10-1:40 — Volunteer Flow & Claim
Show: Volunteer browsing feed, filters, claims task, ETA, messaging with resident.
Voiceover: "Volunteers can filter by distance and category, claim tasks, and message securely."

1:40-2:00 — Paywall & RevenueCat Subscription
Show: Paywall screen, purchase flow, RevenueCat purchase callback success (show entitlement active).
Voiceover: "Supporters can subscribe to fund local microgrants; subscriptions managed by RevenueCat."

2:00-2:20 — Web Donation Flow
Show: Tap Donate -> open web checkout -> success page -> app shows thank-you badge.
Voiceover: "One-time Boost donations are handled via Stripe Checkout and synced to the app."

2:20-2:50 — Admin / Organizer Features
Show: Organizer dashboard, approve assignment, export CSV.
Voiceover: "Organizers get tools to manage volunteers and priority listings."

2:50-3:00 — Closing
Show: Logo and CTA to download, App Store link on screen.
Voiceover: "CareBridge — help local communities, one small action at a time."

Recording notes:
- Record on iPhone device running the app.
- Keep camera stable; focus on screen capture where possible (iOS Screen Recording).
- No copyrighted music; use ambient or royalty-free music if desired.
