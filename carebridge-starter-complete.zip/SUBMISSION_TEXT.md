
Submission Text for RevenueCat Shipaton — CareBridge

Project Title: CareBridge — Community Care Network
One-line: Hyperlocal volunteer coordination with subscriptions & donations managed via RevenueCat.

Long Description:
CareBridge connects residents, volunteers, and small nonprofits to provide time-sensitive assistance — groceries, medication pickup, wellness calls, transport. The app uses TiDB? (or Firebase) backend for requests and metadata, while RevenueCat manages subscriptions and entitlements. One-time Boost donations use Stripe Checkout and are recorded on the server and displayed in-app as thank-you badges.

Features & Functionality:
- Resident request creation (category, urgency, optional donation)
- Volunteer discovery and claim flow (geofenced feed)
- In-app messaging with safety checklists
- Supporter and Organizer subscriptions (RevenueCat)
- Web-based one-time donations (Stripe) integrated with app UI
- Admin dashboard for organizers
- RevenueCat webhook listener to sync entitlements

Demo Video Link: https://youtu.be/YOUR_VIDEO_ID
App Store URL: https://apps.apple.com/app/carebridge-community/idXXXXXXXXX
Promo Code for Judges: CAREJUDGE2025 (example — create in App Store Connect)
Offerings JSON: See revenuecat_offerings.json in the repo

Notes:
- 7-day free trial available for new subscribers (configured in App Store Connect)
- Server stub provided in /server to demonstrate Stripe Checkout session creation and RevenueCat webhook listener
