# Run Instructions — CareBridge Starter

## Prerequisites
- Xcode 15+ (for iOS SwiftUI app)
- Node.js 18+
- CocoaPods or Swift Package Manager for dependencies
- RevenueCat account + API key
- Stripe account (for web one-time donations)
- Apple Developer account for App Store Connect

## iOS App (SwiftUI)
1. Open `ios/CareBridge.xcodeproj` (if you create an Xcode project) or open the `ios/` folder in Xcode.
2. Install RevenueCat SDK:
   - Using Swift Package Manager: add package `https://github.com/RevenueCat/purchases-ios`
3. In `AppDelegate` or `@main` app entry, set your RevenueCat API key:
   ```swift
   Purchases.configure(withAPIKey: "<REVENUECAT_API_KEY>")
   ```
4. Build & Run on a simulator or device.

## Server (Node.js)
1. Install dependencies:
   ```bash
   cd server
   npm install
   ```
2. Create `.env` with:
   ```
   PORT=4242
   STRIPE_SECRET_KEY=sk_test_xxx
   REVENUECAT_WEBHOOK_SECRET=<your_revenuecat_secret>
   ```
3. Start server:
   ```bash
   node index.js
   ```

## Notes
- Replace placeholder API keys before testing.
- For App Store submission, create subscription SKUs in App Store Connect that match identifiers used in the app.
- Provide a 7-day free trial in App Store Connect (or include promo codes) for judge testing.

