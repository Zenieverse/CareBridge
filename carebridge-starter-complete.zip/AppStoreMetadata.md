
App Name: CareBridge — Community Care Network
Subtitle: Neighbors helping neighbors — safe, local assistance & volunteer coordination
Description: 
CareBridge connects residents in need with trusted local volunteers and nonprofit organizers.
Create requests (groceries, meds, check-ins), claim tasks, chat securely, and support your community.
Supporters subscribe to small monthly plans that fund local microgrants; organizers can subscribe to manage teams.

Keywords: community,volunteer,help,neighbors,local,donate,support
Support URL: https://your-domain.example.com/support
Marketing URL: https://your-domain.example.com
Privacy Policy URL: https://your-domain.example.com/privacy
Primary Category: Lifestyle
Secondary Category: Health & Fitness
Age Rating: 12+
Release Notes: Initial release — Core features: request creation, volunteer matching, in-app subscriptions & web donations.
