import SwiftUI
import RevenueCat

struct ContentView: View {
    @State private var showingPaywall = false
    @State private var entitlementActive = false

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("CareBridge")
                    .font(.largeTitle)
                    .bold()

                Text("Connect with local volunteers and support your community.")
                    .multilineTextAlignment(.center)
                    .padding()

                Button("Create Request") {
                    // push to create request UI (not implemented in scaffold)
                }
                .buttonStyle(.borderedProminent)

                Button("Become a Supporter — $3.99/mo") {
                    showingPaywall = true
                }
                .buttonStyle(.bordered)

                if entitlementActive {
                    Text("Supporter benefits active ✅")
                        .foregroundColor(.green)
                }

                Spacer()
            }
            .padding()
            .sheet(isPresented: $showingPaywall) {
                PaywallView(onPurchase: {
                    // In a real app, verify entitlements via Purchases.shared.getCustomerInfo()
                    entitlementActive = true
                    showingPaywall = false
                })
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
