# CareBridge — Community Care Network (Starter Repo)

CareBridge is a hyperlocal community care network connecting residents, volunteers, and small nonprofits.
This starter repo provides a SwiftUI skeleton with RevenueCat integration points and a small Node.js server stub
for handling Stripe Checkout and RevenueCat webhooks.

**What’s included**
- `ios/` — SwiftUI starter app with RevenueCat initialization and demo paywall UI.
- `server/` — Node.js Express server stub for Stripe Checkout + RevenueCat webhooks.
- `assets/` — placeholder 1024x1024 app icon and a screenshot (1179x2556) for submission.
- `RUN_INSTRUCTIONS.md` — steps to run both app and server.
- `LICENSE` — MIT license.

This repo is intended as a hackathon-ready scaffold: implement your app logic and replace placeholders with real keys before publishing.



## Additional Deliverables Added
- Swift Package manifest (open in Xcode)
- RevenueCat Offerings JSON
- Demo script + storyboard
- Submission text template
- Server deployment configs (Heroku/Vercel)
